<?php
require 'database.php'; // makes $conn

$username = 'admin';
$plain = 'Admin@123';
$hash = password_hash($plain, PASSWORD_DEFAULT);

$stmt = $conn->prepare("INSERT INTO admin (username, password) VALUES (?, ?)");
$stmt->bind_param("ss", $username, $hash);
if ($stmt->execute()) {
    echo "Admin created.";
} else {
    echo "Error: " . $conn->error;
}
$stmt->close();
$conn->close();
?>
