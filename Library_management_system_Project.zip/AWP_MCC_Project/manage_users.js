// Function to Fetch Users
function fetchUsers() {
    console.log("Fetching users...");
    fetch('fetch_users.php')
        .then(response => response.json())
        .then(data => {
            console.log("Fetched users:", data);
            const userTable = document.getElementById('userTable');
            userTable.innerHTML = '';

            data.forEach(user => {
                userTable.innerHTML += `
                    <tr>
                        <td><input type="checkbox" class="user-checkbox" value="${user.id}"></td>
                        <td>${user.id}</td>
                        <td>${user.username}</td>
                        <td>${user.email}</td>
                        <td>
                            <button class="btn btn-danger" onclick="deleteUser(${user.id})">Delete</button>
                        </td>
                    </tr>
                `;
            });
        })
        .catch(error => console.error('Error fetching users:', error));
}

// Function to Add User
function addUser() {
    const username = prompt("Enter username:");
    const email = prompt("Enter email:");

    if (username && email) {
        fetch('add_users.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `username=${encodeURIComponent(username)}&email=${encodeURIComponent(email)}`
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            fetchUsers();
        })
        .catch(error => console.error('Error adding user:', error));
    }
}

// Function to Delete Single User
function deleteUser(userId) {
    if (confirm("Are you sure you want to delete this user?")) {
        fetch(`delete_user.php?id=${userId}`)
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                fetchUsers();
            })
            .catch(error => console.error('Error deleting user:', error));
    }
}

// Function to Delete Selected Users
function deleteSelectedUsers() {
    const selectedUsers = [...document.querySelectorAll('.user-checkbox:checked')].map(user => user.value);

    if (selectedUsers.length === 0) {
        alert("No users selected for deletion.");
        return;
    }

    if (confirm("Are you sure you want to delete selected users?")) {
        selectedUsers.forEach((userId, index) => {
            setTimeout(() => {
                fetch(`delete_user.php?id=${userId}`)
                    .then(response => response.json())
                    .then(data => {
                        console.log(data.message);
                        fetchUsers(); // Refresh table after deletion
                    })
                    .catch(error => console.error('Error deleting user:', error));
            }, index * 500); // Adding slight delay to prevent race condition
        });
    }
}

// Function to Search Users
function searchUser() {
    const searchInput = document.getElementById('searchUser').value.toLowerCase();
    const rows = document.querySelectorAll("#userTable tr");

    rows.forEach(row => {
        const username = row.cells[2].textContent.toLowerCase();
        row.style.display = username.includes(searchInput) ? "" : "none";
    });
}

// Auto Load Users When Page Loads
document.addEventListener("DOMContentLoaded", fetchUsers);
