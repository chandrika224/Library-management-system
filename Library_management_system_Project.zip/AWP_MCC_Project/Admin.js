function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(section => {
        section.style.display = 'none';
    });
    document.getElementById(sectionId).style.display = 'block';
}

function fetchUsers() {
    fetch('fetch_users.php')
        .then(response => response.json())
        .then(data => {
            console.log("Fetched Users:", data); // Debugging

            const userTable = document.getElementById('userTable');
            userTable.innerHTML = '';

            data.forEach(user => {
                userTable.innerHTML += `
                    <tr class="user-row">
                        <td>${user.id}</td>
                        <td class="username">${user.username}</td>
                        <td class="email">${user.email}</td>
                        <td>
                            <button class="btn btn-danger" onclick="deleteUser(${user.id})">Delete</button>
                        </td>
                    </tr>
                `;
            });
        })
        .catch(error => console.error('Error fetching users:', error));
}

function addUser() {
    const username = prompt("Enter username:");
    const email = prompt("Enter email:");

    if (username && email) {
        fetch('add_user.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `username=${encodeURIComponent(username)}&email=${encodeURIComponent(email)}`
        })
        .then(response => {
            if (!response.ok) {
                throw new Error("Failed to add user.");
            }
            return response.text();
        })
        .then(() => {
            alert("User added successfully!");
            fetchUsers();
        })
        .catch(error => console.error('Error adding user:', error));
    }
}

function deleteUser(userId) {
    if (!userId) {
        alert("Invalid user ID.");
        return;
    }

    if (confirm("Are you sure you want to delete this user?")) {
        fetch(`delete_user.php?id=${userId}`, { method: 'GET' })
        .then(response => {
            if (!response.ok) {
                throw new Error("Failed to delete user.");
            }
            return response.text();
        })
        .then(() => {
            alert("User deleted successfully!");
            fetchUsers();
        })
        .catch(error => console.error('Error deleting user:', error));
    }
}

function searchUser() {
    document.getElementById("searchBar").addEventListener("keyup", function() {
    let searchText = this.value.toLowerCase();
    document.querySelectorAll(".user-row").forEach(row => {
        let username = row.querySelector(".username").innerText.toLowerCase();
        let email = row.querySelector(".email").innerText.toLowerCase();
        row.style.display = (username.includes(searchText) || email.includes(searchText)) ? "" : "none";
    });
});

}
