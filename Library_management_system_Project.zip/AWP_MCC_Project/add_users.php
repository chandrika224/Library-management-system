<?php
include 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'], $_POST['email'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);

    // Validate inputs
    if (empty($username) || empty($email)) {
        echo json_encode(["status" => "error", "message" => "Username and email are required."]);
        exit;
    }

    // Prepared statement to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO users (username, email) VALUES (?, ?)");
    $stmt->bind_param("ss", $username, $email);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "User added successfully!"]);
    } else {
        echo json_encode(["status" => "error", "message" => $stmt->error]);
    }

    $stmt->close();
}

$conn->close();
?>
